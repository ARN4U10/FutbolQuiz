const questions = [
  {
    question: "¿Qué país ha ganado más Copas del Mundo?",
    answers: ["Alemania", "Italia", "Brasil", "Argentina"],
    correct: 2
  },
  {
    question: "¿Quién ganó el Balón de Oro en 2022?",
    answers: ["Lionel Messi", "Karim Benzema", "Cristiano Ronaldo", "Luka Modric"],
    correct: 1
  },
  {
    question: "¿Qué equipo ganó la Champions League 2023?",
    answers: ["Real Madrid", "Manchester City", "Liverpool", "Bayern Múnich"],
    correct: 1
  },
  {
    question: "¿Qué jugador tiene más goles en la historia del fútbol?",
    answers: ["Cristiano Ronaldo", "Pelé", "Messi", "Romário"],
    correct: 0
  },
  {
    question: "¿Dónde se celebró el Mundial 2018?",
    answers: ["Brasil", "Qatar", "Alemania", "Rusia"],
    correct: 3
  },
  {
    question: "¿Quién es conocido como 'La Pulga'?",
    answers: ["Cristiano Ronaldo", "Neymar", "Messi", "Mbappé"],
    correct: 2
  },
];